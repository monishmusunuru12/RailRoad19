package com.sample.test.demo.utils;

import java.util.List;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.lang3.StringUtils;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.json.JSONObject;
import org.testng.Assert;

@JsonInclude(Include.NON_EMPTY)
public class Order extends BaseTest {

    private String id = "";
    private List<Pizza> items;

    Pizza pizza = new Pizza();

    public Order setId(String id) {
        this.id = id;
        return this;
    }

    public String getId() {
        return id;
    }


    public void addNewTopping(List l, String s) {
        RestAssured.baseURI = url;
        RequestSpecification request = RestAssured.given();
        Response response = request.get("/toppings");
        if (l.contains(s)) {
            int statusCode = response.getStatusCode();
            Assert.assertTrue(statusCode == 500, "Recieved Error code: " + statusCode);
            String successCode = response.jsonPath().get("SuccessCode");
            Assert.assertEquals("Duplicate Topping", successCode, "NOT a Duplicate Topping");
        }
        // JSONObject is a class that represents a Simple JSON.
        // We can add Key - Value pairs using the put method
        JSONObject requestParams = new JSONObject();
        requestParams.put("id", 1);
        requestParams.put("name", "" + s);
        // Add a header stating the Request body is a JSON
        request.header("Content-Type", "application/json");
        // Add the Json to the body of the request
        request = request.body(requestParams.toString());
        // Post the request and check the response
        response = request.post("toppings");
        // Assertion
        int statusCode = response.getStatusCode();
        Assert.assertTrue(statusCode == 201, "Recieved Error code: " + statusCode);
    }

    public void addDuplicateTopping(List l, String s) {
        RestAssured.baseURI = url;
        RequestSpecification request = RestAssured.given();
        // JSONObject is a class that represents a Simple JSON.
        // We can add Key - Value pairs using the put method
        JSONObject requestParams = new JSONObject();
        requestParams.put("id", 1);
        requestParams.put("name", "" + s);
        // Add a header stating the Request body is a JSON
        request.header("Content-Type", "application/json");
        // Add the Json to the body of the request
        request = request.body(requestParams.toString());
        // Post the request and check the response
        Response response = request.post("toppings");
        // Assertion
        int statusCode = response.getStatusCode();
        Assert.assertTrue(statusCode == 405, "Recieved Error code: " + statusCode);
    }

    public void addNewOrder() {
        RestAssured.baseURI = url;
        RequestSpecification request = RestAssured.given();
        // JSONObject is a class that represents a Simple JSON.
        // We can add Key - Value pairs using the put method
        JSONObject requestParams = new JSONObject();
        requestParams.put("pizza", "Large-2 Slices");
        requestParams.put("topping", "Spinach");
        // Add a header stating the Request body is a JSON
        request.header("Content-Type", "application/json");
        // Add the Json to the body of the request
        request = request.body(requestParams.toString());
        // Post the request and check the response
        Response response = request.post("orders");
        // Assertion
        int statusCode = response.getStatusCode();
        Assert.assertTrue(statusCode == 201, "Recieved Error code: " + statusCode);
    }

    public void verifyAddingincorrectToppings() {
        RestAssured.baseURI = url;
        RequestSpecification request = RestAssured.given();
        // JSONObject is a class that represents a Simple JSON.
        // We can add Key - Value pairs using the put method
        JSONObject requestParams = new JSONObject();
        requestParams.put("pizza", "Large 3 Topping");
        requestParams.put("topping", "s");
        // Add a header stating the Request body is a JSON
        request.header("Content-Type", "application/json");
        // Add the Json to the body of the request
        request = request.body(requestParams.toString());
        // Post the request and check the response
        Response response = request.post("orders");
        // Assertion
        int statusCode = response.getStatusCode();
        Assert.assertTrue(statusCode == 406, "Recieved Error code: " + statusCode);
    }

    public void verifyAddinginvalidPizza() {
        RestAssured.baseURI = url;
        RequestSpecification request = RestAssured.given();
        // JSONObject is a class that represents a Simple JSON.
        // We can add Key - Value pairs using the put method
        JSONObject requestParams = new JSONObject();
        requestParams.put("pizza", "");
        requestParams.put("topping", "Spinach");
        // Add a header stating the Request body is a JSON
        request.header("Content-Type", "application/json");
        // Add the Json to the body of the request
        request = request.body(requestParams.toString());
        // Post the request and check the response
        Response response = request.post("orders");
        // Assertion
        int statusCode = response.getStatusCode();
        Assert.assertTrue(statusCode == 407, "Recieved Error code: " + statusCode);
    }

    public void verifyPizzaNotSpecified() {
        RestAssured.baseURI = url;
        RequestSpecification request = RestAssured.given();
        // JSONObject is a class that represents a Simple JSON.
        // We can add Key - Value pairs using the put method
        JSONObject requestParams = new JSONObject();
        requestParams.put("topping", "Spinach");
        // Add a header stating the Request body is a JSON
        request.header("Content-Type", "application/json");
        // Add the Json to the body of the request
        request = request.body(requestParams.toString());
        // Post the request and check the response
        Response response = request.post("orders");
        // Assertion
        int statusCode = response.getStatusCode();
        Assert.assertTrue(statusCode == 408, "Recieved Error code: " + statusCode);
    }

    public void verifyToppingsNotSpecified() {
        RestAssured.baseURI = url;
        RequestSpecification request = RestAssured.given();
        // JSONObject is a class that represents a Simple JSON.
        // We can add Key - Value pairs using the put method
        JSONObject requestParams = new JSONObject();
        requestParams.put("pizza", "Large-2 Slices 3 topping");
        // Add a header stating the Request body is a JSON
        request.header("Content-Type", "application/json");
        // Add the Json to the body of the request
        request = request.body(requestParams.toString());
        // Post the request and check the response
        Response response = request.post("orders");
        // Assertion
        int statusCode = response.getStatusCode();
        Assert.assertTrue(statusCode == 409, "Recieved Error code: " + statusCode);
        System.out.println("New order created is: " + requestParams);
    }


    public void deleteTopping(int id) {
        RestAssured.baseURI = url;
        RequestSpecification request = RestAssured.given();
        // Post the request and check the response
        Response response = request.delete("toppings/" + id);
        // Assertion
        int statusCode = response.getStatusCode();
        Assert.assertTrue(statusCode == 200, "Recieved Error code: " + statusCode);
    }

    public void deleteToppingNotThere(int id) {
        RestAssured.baseURI = url;
        RequestSpecification request = RestAssured.given();
        // Post the request and check the response
        Response response = request.delete("toppings/" + id);
        // Assertion
        int statusCode = response.getStatusCode();
        Assert.assertTrue(statusCode == 404, "Recieved Error code: " + statusCode);
    }


    public void getListofOrders() {
        RestAssured.baseURI = url;
        RequestSpecification request = RestAssured.given();
        // Post the request and check the response
        Response response = request.get("orders");
        // Assertion
        int statusCode = response.getStatusCode();
        Assert.assertTrue(statusCode == 200, "Recieved Error code: " + statusCode);
        String resData = response.getBody().asString();
        System.out.println("" + resData);
    }

    public void getOrderDetails(int id) {
        RestAssured.baseURI = url;
        RequestSpecification request = RestAssured.given();
        // Post the request and check the response
        Response response = request.get("orders/" + id);
        String resData = response.getBody().asString();
        int statusCode = response.getStatusCode();
        Assert.assertTrue(statusCode == 200, "Recieved Error code: " + statusCode);
        System.out.println("" + resData);
    }

    public Order setItems(List<Pizza> items) {
        this.items = items;
        return this;
    }

    public List<Pizza> getItems() {
        return items;
    }

    @Override
    public String toString() {
        String result = "";
        if (StringUtils.isNotBlank(getId())) {
            result += " id: " + getId();
        }
        if (getItems() != null && getItems().size() > 0) {
            result += " items: " + getItems().toString();
        }
        return result;
    }

}
