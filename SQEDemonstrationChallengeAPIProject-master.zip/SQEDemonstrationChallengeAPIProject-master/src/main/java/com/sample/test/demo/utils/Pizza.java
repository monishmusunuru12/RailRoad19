package com.sample.test.demo.utils;

import java.util.ArrayList;
import java.util.List;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.lang3.StringUtils;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.json.JSONArray;
import org.json.JSONObject;


@JsonInclude(Include.NON_EMPTY)
public class Pizza extends BaseTest {

    private String item = "";
    private String pizza = "";
    private List<String> toppings;

    public Pizza setItem(String item) {
        this.item = item;
        return this;
    }

    public String getItem() {
        return item;
    }

    public Pizza setPizza(String pizza) {
        this.pizza = pizza;
        return this;
    }

    public String getPizza() {
        return pizza;
    }

    public Pizza setToppings(List<String> toppings) {
        this.toppings = toppings;
        return this;
    }

    public List<String> getToppings() {

        // get list of toppings and store into a list
        RestAssured.baseURI = url;
        List list = new ArrayList();
        //Request object
        RequestSpecification httpRequest = RestAssured.given();
        //Response object
        Response response = httpRequest.get("/toppings");
        //response.body().toString();
        String resData = response.getBody().asString();
        JSONArray jA = new JSONArray(resData);
        for (int i = 1; i < jA.length(); i++) {
            JSONObject jsonObj = jA.getJSONObject(i);
            list.add(jsonObj.getString("name"));
        }
        System.out.println(list);
        return list;
    }

    public void getListOfPizzas() {
        // get list of toppings and store into a list
        RestAssured.baseURI = url;
        List list = new ArrayList();
        //Request object
        RequestSpecification httpRequest = RestAssured.given();
        //Response object
        Response response = httpRequest.get("/pizzas");
        String resData = response.getBody().asString();
        // Print the list
        System.out.println("" + resData);
    }

    @Override
    public String toString() {
        String result = "";
        if (StringUtils.isNotBlank(getItem())) {
            result += " item: " + getItem();
        }
        if (StringUtils.isNotBlank(getPizza())) {
            result += " pizza: " + getPizza();
        }
        if (getToppings() != null && getToppings().size() > 0) {
            result += " toppings: " + getToppings();
        }
        return result;
    }

}
