package com.sample.test.demo.utils;

public class BaseTest {

    public static final String url = "https://my-json-server.typicode.com/sa2225/demo";

}
