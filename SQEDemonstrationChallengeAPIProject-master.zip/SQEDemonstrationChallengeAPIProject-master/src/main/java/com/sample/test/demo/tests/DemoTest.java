package com.sample.test.demo.tests;

import static io.restassured.RestAssured.given;

import com.sample.test.demo.utils.Order;
import com.sample.test.demo.utils.Pizza;
import org.testng.annotations.Test;
import com.sample.test.demo.utils.BaseTest;

import java.util.List;

public class DemoTest extends BaseTest {
    Pizza p = new Pizza();

    Order order = new Order();

    @Test
    public void demoTest() {
        given().when().get(url).then().assertThat().statusCode(200);
        System.out.println("SUCCESS");
    }

    @Test
    public void getListOfAllToppings() {
        p.getToppings();
    }

    @Test
    public void getListOfAllOrders() {
        order.getListofOrders();
        given().when().get(url).then().assertThat().statusCode(200);
    }

    @Test
    public void verifyAddNewTopping() {
        List list = p.getToppings();
        order.addNewTopping(list, "RedPPepper");
    }

    @Test
    public void verifyAddingDuplicateTopping() {
        List list = p.getToppings();
        order.addDuplicateTopping(list, "Salami");
    }

    @Test
    public void verifyCreatingNewOrder() {
        order.addNewOrder();
    }

    @Test
    public void verifyCreatingOrderWithIncorrectToppings() {
        order.verifyAddingincorrectToppings();
    }

    @Test
    public void verifyCreatingOrderWithInvalidPizza() {
        order.verifyAddinginvalidPizza();
    }

    @Test
    public void verifyCreatingOrderWithPizzaNotSpecified() {
        order.verifyPizzaNotSpecified();
    }

    @Test
    public void verifyCreatingOrderWithToppingsNotSpecified() {
        order.verifyToppingsNotSpecified();
    }

    @Test
    public void verifySpecificOrderDetails() {
        order.getOrderDetails(2);
    }

    @Test
    public void verifyDeleteTopping() {
        order.deleteTopping(1);
    }

    @Test
    public void verifyDeleteToppingResourceNotFound() {
        order.deleteToppingNotThere(100);
    }

    @Test
    public void getListOfAllPizzas() {
        p.getListOfPizzas();
    }
}
